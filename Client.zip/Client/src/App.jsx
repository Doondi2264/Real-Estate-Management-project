import React from 'react';
import Dashboard from './components/Dashboard/dashboard';
import Login from './components/Login/login';
import Register from './components/Register/register';
import BookingForm from './components/BookingForm';
import Feedback from './components/Feedback';
import SellerDetails from './components/Dashboard/SellerDetails/SellerDetails';
import MyBookings from './components/MyBookings/MyBookings'; // Import MyBookings

import {
    createBrowserRouter,
    RouterProvider,
} from 'react-router-dom';

const router = createBrowserRouter([
    { path: '/', element: <Login /> },
    { path: '/login', element: <Login /> },
    { path: '/register', element: <Register /> },
    { path: '/dashboard', element: <Dashboard /> },
    { path: '/book/:propertyId', element: <BookingForm /> },
    { path: '/feedback', element: <Feedback /> },
    { path: '/sellerdetails/:propertyId', element: <SellerDetails /> },
    { path: '/mybookings', element: <MyBookings /> }, // Corrected route path
]);

function App() {
    return <RouterProvider router={router} />;
}

export default App;