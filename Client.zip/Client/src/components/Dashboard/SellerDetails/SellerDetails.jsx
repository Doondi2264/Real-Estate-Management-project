import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import "../../Login/login.css";



function SellerDetails() {
    const { propertyId } = useParams();
    const navigate = useNavigate();
    const [sellerDetails, setSellerDetails] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    // Updated seller list
    const sampleSellerDetails = {
        1: { name: 'John Doe', phone: '123-456-7890', email: 'john.doe@example.com' },
        2: { name: 'Jane Smith', phone: '987-654-3210', email: 'jane.smith@example.com' },
        3: { name: 'Alice Johnson', phone: '555-123-4567', email: 'alice.johnson@example.com' },
        4: { name: 'Bob Williams', phone: '111-222-3333', email: 'bob.williams@example.com' },
        5: { name: 'Charlie Brown', phone: '444-555-6666', email: 'charlie.brown@example.com' },
        6: { name: 'Diana Miller', phone: '777-888-9999', email: 'diana.miller@example.com' },
        7: { name: 'Ethan Davis', phone: '222-333-4444', email: 'ethan.davis@example.com' },
        8: { name: 'Fiona Wilson', phone: '666-777-8888', email: 'fiona.wilson@example.com' },
        9: { name: 'George Garcia', phone: '333-444-5555', email: 'george.garcia@example.com' },
        10: { name: 'Hannah Rodriguez', phone: '888-999-0000', email: 'hannah.rodriguez@example.com' },
        11: { name: 'Ian Thompson', phone: '999-555-1111', email: 'ian.thompson@example.com' },
        12: { name: 'Jessica Lee', phone: '777-222-4444', email: 'jessica.lee@example.com' },
    };

    useEffect(() => {
        setLoading(true);
        setTimeout(() => {
            const details = sampleSellerDetails[propertyId];
            if (details) {
                setSellerDetails(details);
            } else {
                setError('Seller details not found.');
            }
            setLoading(false);
        }, 500);
    }, [propertyId]);

    const handleBack = () => {
        navigate(-1);
    };

    return (
        <div className="wrapper"> {/* Applying login page styling */}
            <div className="seller-details-box">
                {loading ? (
                    <div className="seller-details">Loading seller details...</div>
                ) : error ? (
                    <div className="seller-details error">{error}</div>
                ) : (
                    <>
                        <h2>Seller Details</h2>
                        <div className="detail">
                            <strong>Name:</strong> {sellerDetails.name}
                        </div>
                        <div className="detail">
                            <strong>Phone:</strong> {sellerDetails.phone}
                        </div>
                        <div className="detail">
                            <strong>Email:</strong> {sellerDetails.email}
                        </div>
                        <button onClick={handleBack} className="back-button">Back</button>
                    </>
                )}
            </div>
        </div>
    );
}

export default SellerDetails;
