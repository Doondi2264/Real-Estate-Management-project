import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './MyBookings.css';
import { useNavigate } from 'react-router-dom';

function MyBookings() {
    const [bookings, setBookings] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const userId = localStorage.getItem('userId'); // Ensure userId is correctly stored
    const navigate = useNavigate();

    useEffect(() => {
        const fetchBookings = async () => {
            setLoading(true);
            try {
                if (!userId) {
                    throw new Error('User not logged in.');
                }

                const response = await axios.get(`http://localhost:5000/api/bookings/${userId}`); // ✅ Updated API endpoint

                console.log('API Response:', response.data);

                if (Array.isArray(response.data) && response.data.length > 0) {
                    setBookings(response.data);
                } else {
                    setBookings([]);
                    setError('No bookings found.');
                }
            } catch (err) {
                setError(err.message || 'Failed to fetch bookings.');
            } finally {
                setLoading(false);
            }
        };

        fetchBookings();
    }, [userId]);

    const handleGoToDashboard = () => {
        navigate('/dashboard');
    };

    if (loading) {
        return <div className="my-bookings"><p>Loading bookings...</p></div>;
    }

    if (error) {
        return <div className="my-bookings"><p className="error">{error}</p></div>;
    }

    return (
        <div className="my-bookings">
            <h2>My Bookings</h2>
            {bookings.length > 0 ? (
                <ul className="bookings-list">
                    {bookings.map((booking) => (
                        <li key={booking._id} className="booking-item">
                            <p><strong>Property ID:</strong> {booking.propertyId}</p>
                            <p><strong>Booking Date:</strong> {new Date(booking.bookingDate).toLocaleDateString()}</p>
                            <p><strong>Details:</strong> {booking.bookingDetails}</p>
                            <p><strong>Name:</strong> {booking.name}</p>
                            <p><strong>Phone:</strong> {booking.phone}</p>
                            <p><strong>Email:</strong> {booking.email}</p>
                        </li>
                    ))}
                </ul>
            ) : (
                <p>No bookings found.</p>
            )}
            <button onClick={handleGoToDashboard}>Go to Dashboard</button>
        </div>
    );
}

export default MyBookings;
