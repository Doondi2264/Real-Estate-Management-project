const express = require('express');
const router = express.Router();
const pool = require('../db');

// Create Booking
router.post('/bookings', async (req, res) => {
    try {
        const { userId, propertyId, bookingDate, bookingDetails, name, phone, email } = req.body; // Added name, phone, email
        const [result] = await pool.query(
            'INSERT INTO bookings (userId, propertyId, bookingDate, bookingDetails, name, phone, email) VALUES (?, ?, ?, ?, ?, ?, ?)', // Added name, phone, email to query
            [userId, propertyId, bookingDate, bookingDetails, name, phone, email]
        );
        res.status(201).json({ bookingId: result.insertId, ...req.body });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: error.message });
    }
});

// Get User Bookings
router.get('/bookings/user/:userId', async (req, res) => {
    try {
        const userId = req.params.userId;
        const [rows] = await pool.query('SELECT * FROM bookings WHERE userId = ?', [userId]);
        res.json(rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;